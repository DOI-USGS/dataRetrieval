# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("dataRetrieval/",reset = TRUE)
setwd("D:/LADData/RCode/dataRetrieval")
document()
check()  

#Add hidden functions:
export(formatCheckDate)
export(checkStartEndDate)
export(dateFormatCheck)
export(formatCheckParameterCd)
export(formatCheckSiteNumber)

# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
build("dataRetrieval")
install("dataRetrieval")