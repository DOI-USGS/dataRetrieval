# Build the package:
library(devtools)
setwd("D:/LADData/RCode/")
load_all("dataRetrievalGitorious/",reset = TRUE)
setwd("D:/LADData/RCode/dataRetrievalGitorious")
document()
check()  
# run_examples()
# test()   #Assumes testthat type tests in GLRI/inst/tests
setwd("D:/LADData/RCode/")
build("dataRetrievalGitorious")
install("dataRetrievalGitorious")